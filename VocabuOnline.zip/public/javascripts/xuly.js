$(document).ready(function () {
    var socket = io('/');
    socket.on('send-username', $('#profile-username').html());
    socket.on('server-send-question', function (question) {
        $('#cauhoi').html(question.content);
        if (question.type === 'av') {
            $('#type').html(' nghĩa là gì ?');
        } else {
            $('#type').html(' trong tiếng anh là gì ?');
        }
    });

    socket.on('server-send-answer-final', function (userQuestion) {
        $('#my-question').val('');
        if (userQuestion.username === 'no') {
            $('#time').html('Không ai trả lời đúng câu hỏi này. Đáp án là: ' + userQuestion.answer);

        } else
            $('#time').html('Chúc mừng bạn ' + userQuestion.username + " đã trả lời đúng và nhanh nhất. Đáp án là: " + userQuestion.answer);
    });


    socket.on('server-send-time', function (time) {
        $('#time').html(time);
    });

    socket.on('server-send-answer', function (listQuestion) {
        $('#user-answer').empty();
        listQuestion.forEach(function (data) {
            $('#user-answer').prepend('<tr>' +
                '<td>' + data.username + '</td>' +
                '<td>' + data.answer + '</td>' +
                '</tr>');
        })
    });

    socket.on('server-send-list-user', function (data) {
        $('#user').empty();
        $('#numberOfOnline').html(data.length + ' người đang online');
        data.forEach(function (data) {

            $('#user').append('<p>' + data.username + '<span style="float: right" class="badge">' + data.diem + '' + '</span></p>');
        });
    });

    $('#btnAnswerQuestion').on('click', function () {
        socket.emit('user-send-answer', {
            username: $('#profile-username').html(),
            answer: $('#my-question').val()
        });
    });

    $('#my-question').on('keyup', function (event) {
        if (event.keyCode === 13) {
            socket.emit('user-send-answer', {
                username: $('#profile-username').html(),
                answer: $('#my-question').val()
            });
        }
    });



    $('#btnLogin').on('click', function () {
        var username = $('#log_username').val();
        var password = $('#log_password').val();
        setTimeout(function () {
            $.ajax({
                url: '/user/login',
                data: {
                    username: username,
                    password: password
                },
                success: function (data) {
                    var data1 = data.data;
                    if (data1 === 'ok') {
                        window.location.reload();
                    }
                    if (data === 'fail') {
                        $('#log_notify').html('Tài khoản hoặc mật khẩu không đúng');
                    }
                },
                error: function (err) {

                }

            });
        }, 1000);
    });

    $('#btnRegister').on('click', function () {
        var username = $('#reg_username').val();
        var password = $('#reg_password').val();
        var email = $('#reg_email').val();
        var linkfb = $('#reg_linkfb').val();

        $.ajax({
            url: '/user/registry',
            data: {
                username: username,
                password: password,
                email: email,
                linkfb: linkfb
            },
            success: function (data) {
                var data1 = data.data;
                if (data1 === 'ok') {
                    window.location.reload();
                }
                if (data1 === 'fail') {
                    $('#reg_notify').html('Tài khoản đã tồn tại.');
                }
            },
            error: function (err) {
            }

        });
    });

});

// $('#emit').on('click', function () {
//     socket.emit('send-answer', $('#data').val());
// });
// socket.on('server-send-question', function (data) {
//     $('#ddd').html(data);
// });
// socket.on('server-send-question-2', function (data) {
//     $('#ddd2').html(data);
// });