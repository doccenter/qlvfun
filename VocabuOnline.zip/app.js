var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var indexRouter = require('./routes/index');
var app = express();
var session = require('express-session');
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
// Tell express to serve static files from the following directories
// app.use(express.static('public'));
app.use(session({secret: "Shh, its a secret!"}));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/', indexRouter);
var listUser = [];
var listAnswer = [];
var question = {};
var server = require('http').Server(app);
var io = require('socket.io')(server);
var time = 25;
var mysql = require('mysql');
var pool = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'vocubulonline'
});
var currentQuestion = {};

setInterval(function () {
    console.log(listUser);
    if (time >= 21) {
        time--;
        pool.query('SELECT * FROM question ORDER BY RAND() LIMIT 1;', function (error, results, fields) {
            currentQuestion = results[0];
        });
    } else if (time === 20) {
        listAnswer = [];
        io.sockets.emit('server-send-answer', []);
        io.sockets.emit('server-send-question', currentQuestion);
        time--;
    } else if (time === 0) {
        var check = false;
        var ans;
        for (var a = 0; a < listAnswer.length; a++) {
            ans = listAnswer[a];
            if (ans.answer === currentQuestion.answer) {
                check = true;
                break;
            }
        }
        if (check) {
            io.sockets.emit('server-send-question', currentQuestion);
            io.sockets.emit('server-send-answer-final', ans);
            time = 25;


        } else {
            io.sockets.emit('server-send-question', currentQuestion);
            io.sockets.emit('server-send-answer-final', {
                username: 'no',
                answer: currentQuestion.answer
            });
            time = 25;
        }


    } else if (time <= 20) {
        io.sockets.emit('server-send-question', currentQuestion);
        io.sockets.emit('server-send-time', time);
        time--;
    }
}, 1000);

io.on('connection', function (socket) {
    io.sockets.emit('server-send-list-user', listUser);

    // socket.on('send-username', function (data) {
    //     console.log(data);
    //     socket.username = data;
    // });

    socket.on('user-send-answer', function (data) {
        listAnswer.push(data);
        io.sockets.emit('server-send-answer', listAnswer);
    });

    socket.on('disconnect', function () {
        app.use('/logout',function (req, res) {
            res.redirect('/user/logout');
        })
    });
});

function removeUser(username) {

}

app.use('/user/login', function (req, res) {
    let username = req.query.username;
    let password = req.query.password;

    pool.query('SELECT * FROM account WHERE username=? and password=?', [username, password], function (error, results, fields) {
        if (error) return res.status(500).json({data: 'fail'});
        var length = results.length;
        if (length === 0) {
            return res.status(200).json({data: 'fail'});
        }
        var acc = results[0];

        listUser.push(acc);
        req.session.acc = acc;
        return res.status(200).json({data: 'ok'});
    });

});

app.use('/user/registry', function (req, res) {
    let username = req.query.username;
    let password = req.query.password;
    let email = req.query.email;
    let linkfb = req.query.linkfb;
    let diem = 0;
    let status = 0;
    let ip = '';
    let sdt = '';
    let diachi = '';

    pool.query('insert into account values (?,?,?,?,?,?,?,?,?)', [username, password, email, linkfb, diem, status, ip, sdt, diachi], function (error, results, fields) {
        if (error) return res.json({'data': 'fail'});

        var acc = {
            username: username,
            password: password,
            email: email,
            linkfb: linkfb,
            diem: diem,
            status: status,
            ip: ip,
            sdt: sdt,
            diachi: diachi
        };
        listUser.push(acc);
        req.session.acc = acc;
        return res.status(200).json({data: 'ok'});
    });
});


app.use('/user/logout', function (req, res) {
    var username = req.session.acc.username;
    var index = -1;
    for (var i = 0; i < listUser.length; i++) {
        if (listUser[i].username === username) {
            index = i;
        }
    }
    listUser[index] = undefined;
    copy();
    setTimeout(function () {
        req.session.acc = undefined;
        res.redirect('/');
    }, 1000);
});

function copy() {
    var ds = [];
    listUser.forEach(function (data) {
        if (data !== undefined) {
            ds.push(data)
        }
    });
    listUser = ds;
}

server.listen(3000);


module.exports = app;

